#include <stdio.h>

int main() {
    float p1, p2, p3, e, t, prom, CF;

    printf("Ingrese la nota del primer parcial:");
    scanf("%f", &p1);

    printf("Ingrese la nota del segundo parcial:");
    scanf("%f", &p2);

    printf("Ingrese la nota del tercer parcial:");
    scanf("%f", &p3);

    printf("Examen: ");
    scanf("%f", &e);

    printf("Trabajo: ");
    scanf("%f", &t);

    prom = (p1 + p2 + p3) / 3;
    CF = 0.55 * prom + 0.3 * e + 0.15 * t;

    printf("\nCalificación final: %.2f\n", CF);

    return 0;
}